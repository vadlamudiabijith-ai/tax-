import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { email } = await req.json();

    if (!email) {
      return new Response(
        JSON.stringify({ error: "Email is required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Find user by email in auth.users table using service role
    const { data: authData, error: authError } = await supabase.auth.admin.listUsers();
    
    if (authError) {
      throw authError;
    }

    const user = authData.users.find(u => u.email === email);

    if (!user) {
      return new Response(
        JSON.stringify({ error: "User not found" }),
        {
          status: 404,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    // Get user profile with phone number
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("full_name, phone_number")
      .eq("id", user.id)
      .maybeSingle();

    if (profileError) {
      throw profileError;
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // Set expiry time (5 minutes from now)
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 5);

    // Store OTP in database
    const { error: otpError } = await supabase
      .from("otp_codes")
      .insert({
        user_email: email,
        otp_code: otp,
        expires_at: expiresAt.toISOString(),
      });

    if (otpError) {
      throw otpError;
    }

    // In a production environment, you would:
    // 1. Send OTP via SMS using Twilio, AWS SNS, or similar service
    // 2. Send OTP via Email using SendGrid, AWS SES, or similar service
    
    // For demo purposes, we'll log the OTP and return success
    console.log(`OTP for ${email}: ${otp}`);
    console.log(`Would send to phone: ${profile?.phone_number || 'N/A'}`);

    return new Response(
      JSON.stringify({
        success: true,
        message: "OTP sent to your email and phone number",
        // For demo purposes only - NEVER return OTP in production!
        demo_otp: otp,
        phone: profile?.phone_number ? `***${profile.phone_number.slice(-4)}` : null,
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Failed to send OTP" }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});